#include"filter.h"


float ADD_valu[5][10]; 
float ADDD_valu[5]; 
float AD_valu[5];          
float Min_AD[5] = {1,1,1,1,1}; //��Сֵ��Ϊ1
float Max_Ad[5] = {560,123,730,123,780};//���ֵ���ֶ�����
float Range = 250;  //���ֵ�ķ�Χ��0~100
//780  213

void adv_init()
{
	adc_init(ADC_P00,ADC_SYSclk_DIV_2);
	adc_init(ADC_P01,ADC_SYSclk_DIV_2);
	adc_init(ADC_P05,ADC_SYSclk_DIV_2);
	adc_init(ADC_P06,ADC_SYSclk_DIV_2);
	adc_init(ADC_P02,ADC_SYSclk_DIV_2);
}


void read_adc()
{
	uint16 i, j, k;
	float temp;//�����н�ֵ
    static float  adc_value[10][10], ad_sum[10];
	//��ȡ���ֵ
	for(i=0;i<5;i++)
	{
		adc_value[0][i] = adc_once(ADC_P00, ADC_10BIT);
		adc_value[1][i] = adc_once(ADC_P01, ADC_10BIT);
		adc_value[2][i] = adc_once(ADC_P05, ADC_10BIT);
		adc_value[3][i] = adc_once(ADC_P06, ADC_10BIT);
		adc_value[4][i] = adc_once(ADC_P02, ADC_10BIT);
	}
	//ð������
	for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 9; j++)    
        {
            for (k = 0; k < 9 - j; k++)
            {
                if (adc_value[i][k] > adc_value[i][k + 1])   
                {
                    temp = adc_value[i][k + 1];
                    adc_value[i][k + 1] = adc_value[i][k];
                    adc_value[i][k] = temp;
                }
            }
        }
    }
	//ȡ�м��ֵ��ȡ
	for (i = 0; i < 5; i++) 
    {
        ad_sum[i] = adc_value[i][3] + adc_value[i][4] + adc_value[i][5]+adc_value[i][6];
		//AD_valu[i] = ad_sum[i]/4;
        adc_data[i] = ad_sum[i]/4;	//��ֵ                         
    }
/*	
	/////////��һ��/////////
	for(i = 0; i < 5; i++)
    {
      for(j = 0; j < 9; j++)
      {
        ADD_valu[i][j] = ADD_valu[i][j+1];
      }
      ADD_valu[i][j] = AD_valu[i];
    }
    for(i = 0; i < 5; i++)
    {
        ADDD_valu[i] = (ADD_valu[i][0]+ADD_valu[i][1]+ADD_valu[i][2]+ADD_valu[i][3]+ADD_valu[i][4])/5;
    }
    for (i = 0; i < 5; i++) 
    {
        GUI_AD[i] = 100*(ADDD_valu[i] - Min_AD[i])/(Range - Min_AD[i]);
        if (GUI_AD[i] >= Range)
            GUI_AD[i] = Range;
        if (GUI_AD[i] <= Min_AD[i])
            GUI_AD[i] = Min_AD[i];
    }
*/
}

//ƽ�������˲��㷨
float MovingAverageFilter0(float x0)	
{
	static int8 MAF_index0 = -1;
	static float buffer0[MAF_LENGTH];
	static float yk_0 = 0;
	float y0 = 0;
	uint8 i = 0;
	if (MAF_index0 == -1)
	{ 
		for (i = 0; i < MAF_LENGTH; i++)
		{
		  buffer0[i] = x0;
		}
		yk_0 = x0;
		MAF_index0 = 0;
		y0 = yk_0;
	  }
	  else
	  {
		y0 = yk_0 + (x0 - buffer0[MAF_index0]) / MAF_LENGTH;
		buffer0[MAF_index0] = x0;
		MAF_index0++;
		if (MAF_index0 >= MAF_LENGTH)
		{
		  MAF_index0 = 0;
		}
		yk_0 = y0;
  }
  return y0;
}
float MovingAverageFilter1(float x1)
{
	static int8 MAF_index1 = -1;
	static float buffer1[MAF_LENGTH];
	static float yk_1 = 0;
	float y1 = 0;
	uint8 i = 0;
	if (MAF_index1 == -1)
	{
		for (i = 0; i < MAF_LENGTH; i++)
		{
		  buffer1[i] = x1;
		}
		yk_1 = x1;
		MAF_index1 = 0;
		y1 = yk_1;
	  }
	  else
	  {
		y1 = yk_1 + (x1 - buffer1[MAF_index1]) / MAF_LENGTH;
		buffer1[MAF_index1] = x1;
		MAF_index1++;
		if (MAF_index1 >= MAF_LENGTH)
		{
		  MAF_index1 = 0;
		}
		yk_1 = y1;
  }
  return y1;
}

float MovingAverageFilter2(float x2)
{
	static int8 MAF_index2 = -1;
	static float buffer2[MAF_LENGTH];
	static float yk_2 = 0;
	float y2 = 0;
	uint8 i = 0;
	if (MAF_index2 == -1)
	{ 
		for (i = 0; i < MAF_LENGTH; i++)
		{
		  buffer2[i] = x2;
		}
		yk_2 = x2;
		MAF_index2 = 0;
		y2 = yk_2;
	  }
	  else
	  {
		y2 = yk_2 + (x2 - buffer2[MAF_index2]) / MAF_LENGTH;
		buffer2[MAF_index2] = x2;
		MAF_index2++;
		if (MAF_index2 >= MAF_LENGTH)
		{
		  MAF_index2 = 0;
		}
		yk_2 = y2;
  }
  return y2;
}

float MovingAverageFilter3(float x3)
{
	static int8 MAF_index3 = -1;
	static float buffer3[MAF_LENGTH];
	static float yk_3 = 0;
	float y3 = 0;
	uint8 i = 0;
	if (MAF_index3 == -1)
	{ 
		for (i = 0; i < MAF_LENGTH; i++)
		{
		  buffer3[i] = x3;
		}
		yk_3 = x3;
		MAF_index3 = 0;
		y3 = yk_3;
	  }
	  else
	  {
		y3 = yk_3 + (x3 - buffer3[MAF_index3]) / MAF_LENGTH;
		buffer3[MAF_index3] = x3;
		MAF_index3++;
		if (MAF_index3 >= MAF_LENGTH)
		{
		  MAF_index3 = 0;
		}
		yk_3 = y3;
  }
  return y3;
}

float MovingAverageFilter4(float x4)
{
	static int8 MAF_index4 = -1;
	static float buffer4[MAF_LENGTH];
	static float yk_4 = 0;
	float y4 = 0;
	uint8 i = 0;
	if (MAF_index4 == -1)
	{ 
		for (i = 0; i < MAF_LENGTH; i++)
		{
		  buffer4[i] = x4;
		}
		yk_4 = x4;
		MAF_index4 = 0;
		y4 = yk_4;
	  }
	  else
	  {
		y4 = yk_4 + (x4 - buffer4[MAF_index4]) / MAF_LENGTH;
		buffer4[MAF_index4] = x4;
		MAF_index4++;
		if (MAF_index4 >= MAF_LENGTH)
		{
		  MAF_index4 = 0;
		}
		yk_4 = y4;
  }
  return y4;
}

float MovingAverageFilter5(float x5)	
{
	static int8 MAF_index5 = -1;
	static float buffer5[MAF_LENGTH];
	static float yk_5 = 0;
	float y5 = 0;
	uint8 i = 0;
	if (MAF_index5 == -1)
	{ 
		for (i = 0; i < MAF_LENGTH; i++)
		{
		  buffer5[i] = x5;
		}
		yk_5 = x5;
		MAF_index5 = 0;
		y5 = yk_5;
	  }
	  else
	  {
		y5 = yk_5 + (x5 - buffer5[MAF_index5]) / MAF_LENGTH;
		buffer5[MAF_index5] = x5;
		MAF_index5++;
		if (MAF_index5 >= MAF_LENGTH)
		{
		  MAF_index5 = 0;
		}
		yk_5 = y5;
  }
  return y5;
}

float MovingAverageFilter6(float x6)	
{
	static int8 MAF_index6 = -1;
	static float buffer6[MAF_LENGTH];
	static float yk_6 = 0;
	float y6 = 0;
	uint8 i = 0;
	if (MAF_index6 == -1)
	{ 
		for (i = 0; i < MAF_LENGTH; i++)
		{
		  buffer6[i] = x6;
		}
		yk_6 = x6;
		MAF_index6 = 0;
		y6 = yk_6;
	  }
	  else
	  {
		y6 = yk_6 + (x6 - buffer6[MAF_index6]) / MAF_LENGTH;
		buffer6[MAF_index6] = x6;
		MAF_index6++;
		if (MAF_index6 >= MAF_LENGTH)
		{
		  MAF_index6 = 0;
		}
		yk_6 = y6;
  }
  return y6;
}

float MovingAverageFilter7(float x7)	
{
	static int8 MAF_index7 = -1;
	static float buffer7[MAF_LENGTH];
	static float yk_7 = 0;
	float y7 = 0;
	uint8 i = 0;
	if (MAF_index7 == -1)
	{ 
		for (i = 0; i < MAF_LENGTH; i++)
		{
		  buffer7[i] = x7;
		}
		yk_7 = x7;
		MAF_index7 = 0;
		y7 = yk_7;
	  }
	  else
	  {
		y7 = yk_7 + (x7 - buffer7[MAF_index7]) / MAF_LENGTH;
		buffer7[MAF_index7] = x7;
		MAF_index7++;
		if (MAF_index7 >= MAF_LENGTH)
		{
		  MAF_index7 = 0;
		}
		yk_7 = y7;
  }
  return y7;
}

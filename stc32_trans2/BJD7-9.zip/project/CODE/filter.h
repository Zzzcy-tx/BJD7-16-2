#ifndef __FILTER_H
#define __FILTER_H
 
#include "headfile.h"
#include "math.h"
#include "data.h"

#define MAF_LENGTH 5 // ����ƽ���˲�������


void adv_init();
void read_adc();

float MovingAverageFilter0(float x0);
float MovingAverageFilter1(float x1);
float MovingAverageFilter2(float x2);
float MovingAverageFilter3(float x3);
float MovingAverageFilter4(float x4);
float MovingAverageFilter5(float x5);
float MovingAverageFilter6(float x6);
float MovingAverageFilter7(float x7);


#endif
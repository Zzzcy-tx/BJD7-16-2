#include "keyboard.h"

float step = 0;
uint16 KeystrokeLabel = 0;
int16 Dispay_Codename = 0;
uint16 display = 1;
uint16 step_back = 0;

const ButtonLabel_enum ButtonLabels[ButtonCnt] =
    {
        ButtonOne,
        ButtonTwo,
        ButtonThree,
        ButtonFour,
        ButtonFive};

//-------------------------------------------------------------------------------------------------------------------
//  @brief      ����ɨ��
//  @param
//  @param
//  @param
//  @param
//  @return     void
//  @note
//-------------------------------------------------------------------------------------------------------------------

void Keystroke_Scan(void)
{
    static int key_up = 1; // �����ɿ���־
    KeystrokeLabel = 0;
    if (key_up && ((KeyONE == 0) || (KeyTWO == 0) || (KeyTHREE == 0) || (KeyFOUR == 0) || (KeyFIVE == 0)))
    {
        // 	if (mode == SINGLE_CLICK)
        // 		key_up = 0;
        // 	if (mode == DOUBLE_CLICK)
        // 		key_up = 1;
        if (KeyONE == 0)
        {
            KeystrokeLabel = 2;
        }
        else if (KeyTWO == 0)
        {
            KeystrokeLabel = 1;
        }
        else if (KeyTHREE == 0)
        {
            KeystrokeLabel = 3;
        }
        else if (KeyFOUR == 0)
        {
            KeystrokeLabel = 4;
        }
        else if (KeyFIVE == 0)
        {
            KeystrokeLabel = 5;
        }
    }
    // if (mode == SINGLE_CLICK && 1 == KeyONE && 1 == KeyTWO && 1 == KeyTHREE && 1 == KeyFOUR)
    // {
    // 	key_up = 1;
    // }
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      �˵�ת��Ŀ¼
//  @param
//  @params
//  @param
//  @param
//  @return     void
//  @note       ����while����ʾĿ��ҳ��  ��ÿ��ҳ�水�������󶼻�ı䵽��Ӧҳ�棬�˺������ڸ�����Ļ��ʾ
//-------------------------------------------------------------------------------------------------------------------
void Keystroke_Menu(void)
{
    switch (Dispay_Codename)
    {
    case 0:
        Keystroke_Menu_HOME();
        break;
    case 5:
        Keystroke_Menu_STEP();
        break;
    case 1:
        Keystroke_Menu_ONE();
        break;
    case 11:
        Keystroke_Menu_ONE_ONE();
        break;
    case 2:
        Keystroke_Menu_TWO();
        break;
    case 21:
        Keystroke_Menu_TWO_ONE();
        break;
    case 211:
        Keystroke_Menu_TWO_ONE_ONE();
        break;
    case 212:
        Keystroke_Menu_TWO_ONE_TWO();
        break;
    case 22:
        Keystroke_Menu_TWO_TWO();
        break;
    case 221:
        Keystroke_Menu_TWO_TWO_ONE();
        break;
    case 222:
        Keystroke_Menu_TWO_TWO_TWO();
        break;
    case 223:
        Keystroke_Menu_TWO_TWO_TWO();
        break;
    case 3:
        Keystroke_Menu_THREE();
        break;
    case 4:
        Keystroke_Menu_FOUR();
        break;
    }
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      ��ʾ�˵�Ŀ¼
//  @param
//  @param
//  @param
//  @param
//  @return     void
//  @note       ��ҳ��Ϊ���Ϊ0
//-------------------------------------------------------------------------------------------------------------------
void Keystroke_Menu_HOME(void) // 0
{
    // int chosed=0;
    // ips200_Dispaly(BLUE,display*10-10);
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    // for(chosed=0;chosed<3;chosed++)
    // {
    //     if(display%10-1==chosed)
    //     {
    //         ips200_showstr(0,chosed,"*");
    //     }else{
    //         ips200_showstr(0,chosed," ");
    //     }
    // }
    ips200_showstr(8, 0, " speed_set__1"); // 1
    ips200_showstr(8, 1, " pid_set____2"); // 2
    ips200_showstr(8, 2, " adc_get____3"); // 3
    ips200_showstr(8, 3, " data____4");    // 3
    ips200_showstr(8, 45, " display:    ");
    ips200_showuint16(120, 45, display % 10);
    ips200_showstr(80, 50, " homepage");
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = display;
        display = display * 10 + 1;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 0;
        ips200_clear(WHITE);
        break;
    }
}
//-------------------------------------------------------------------------------------------------------------------
//  @brief      ��ʾ����
//  @param
//  @param
//  @param
//  @param
//  @return     void
//  @note       ��ҳ��Ϊ���Ϊ0
//-------------------------------------------------------------------------------------------------------------------
void Keystroke_Menu_STEP(void) // 5
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10, "*");
    ips200_showstr(8, 0, " Step=0_________0"); // 50
    ips200_showstr(8, 1, " Step+=0.1______1"); // 51
    ips200_showstr(8, 2, " Step-=0.1______2"); // 52
    ips200_showstr(8, 3, " Step+=10_______3"); // 53
    ips200_showstr(8, 4, " Step-=10_______4"); // 54
    ips200_showstr(8, 5, " Step+=100______5"); // 55
    ips200_showstr(8, 6, " Step-=100______6"); // 56
    ips200_showstr(8, 7, " Step+=1000_____7"); // 57
    ips200_showstr(8, 8, " Step-=1000_____8"); // 58
    ips200_showstr(8, 9, " =-Step_________5"); // 59
    ips200_showstr(8, 10, " Return pressFOUR");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    ips200_showstr(8, 50, "Step_set");
    ips200_showfloat(120, 50, step, 5, 2);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        if (display == 50)
        {
            step = 0;
        }
        else if (display == 51)
        {
            step += 0.1;
        }
        else if (display == 52)
        {
            step -= 0.1;
        }
        else if (display == 53)
        {
            step += 10;
        }
        else if (display == 54)
        {
            step -= 10;
        }
        else if (display == 55)
        {
            step += 100;
        }
        else if (display == 56)
        {
            step -= 100;
        }
        else if (display == 57)
        {
            step += 1000;
        }
        else if (display == 58)
        {
            step -= 1000;
        }
        else if (display == 59)
        {
            step = -step;
        }
        else
        {
            break;
        }
        break;
    case KeystrokeFOUR:
        Dispay_Codename = step_back;
        display = step_back;
        ips200_clear(WHITE);
        break;
    }
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      �˵�һ
//  @param
//  @param
//  @param
//  @param
//  @return     void
//  @note       ��ҳ��Ϊ���Ϊ0
//-------------------------------------------------------------------------------------------------------------------
void Keystroke_Menu_ONE(void) // 1
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " sp_set__1");
    ips200_showint16(120, 0, sp_set); // 11
    ips200_showstr(8, 1, " sp_set_max__2");
    ips200_showint16(120, 1, sp_set_max); // 12
    ips200_showstr(8, 2, " home__4");     // 0
    ips200_showstr(0, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = display;
        display = display * 10 + 1;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 0;
        display = 1;
        ips200_clear(WHITE);
        break;
    }
}

void Keystroke_Menu_ONE_ONE(void) // 11
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " sp_set+__1");
    ips200_showint16(120, 0, sp_set);
    ips200_showstr(8, 1, " sp_set-__2");
    ips200_showint16(120, 1, sp_set);
    ips200_showstr(8, 2, " Step__3");
    ips200_showfloat(120, 2, step, 4, 2);
    ips200_showstr(8, 3, " Return__5");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = 5;
        display = 51;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 1;
        display = 11;
        ips200_clear(WHITE);
        break;
    }
}
//-------------------------------------------------------------------------------------------------------------------
//  @brief      �˵���
//  @param
//  @param
//  @param
//  @param
//  @return     void
//  @note       ��ҳ��Ϊ���Ϊ0
//-------------------------------------------------------------------------------------------------------------------

void Keystroke_Menu_TWO(void) // 2
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " PidLR_set___1");
    ips200_showstr(8, 1, " PidS_set____2");
    ips200_showstr(8, 2, " Return_FOUR");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = display;
        display = display * 10 + 1;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 0;
        display = 1;
        ips200_clear(WHITE);
        break;
    }
}

void Keystroke_Menu_TWO_ONE(void) // 21
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " P_LR_____1");
    ips200_showfloat(120, 0, P_LR, 4, 2); // 211
    ips200_showstr(8, 1, " I_LR_____2");
    ips200_showfloat(120, 1, I_LR, 4, 2); // 212
    ips200_showstr(8, 2, " Return_FOUR");
    ips200_showstr(8, 45, "display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = display;
        display = display * 10 + 1;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 2;
        display = 21;
        ips200_clear(WHITE);
        break;
    }
}
void Keystroke_Menu_TWO_ONE_ONE(void) // 211
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " P_LR+step__1");
    ips200_showfloat(120, 0, P_LR, 4, 2); // 211
    ips200_showstr(8, 1, " P_LR-step__2");
    ips200_showstr(8, 2, " Step_______3");
    ips200_showfloat(120, 2, step, 4, 2);
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        P_LR = P_LR + step;
        break;
    case KeystrokeTWO:
        P_LR = P_LR - step;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = 5;
        display = 51;
        step_back = 211;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 21;
        display = 211;
        ips200_clear(WHITE);
        break;
    }
}
void Keystroke_Menu_TWO_ONE_TWO(void) // 212
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " I_LR+__1");
    ips200_showfloat(120, 0, I_LR, 4, 2); // 211
    ips200_showstr(8, 1, " I_LR-__2");
    ips200_showstr(8, 2, " Step_____3");
    ips200_showfloat(120, 2, step, 4, 2);
    ips200_showstr(8, 3, " Return_FOUR");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        I_LR = I_LR + step;
        break;
    case KeystrokeTWO:
        I_LR = I_LR - step;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = 5;
        display = 51;
        step_back = 212;
        ips200_clear(WHITE);
        break;
    case KeystrokeFIVE:
        Dispay_Codename = 21;
        display = 211;
        ips200_clear(WHITE);
        break;
    }
}
void Keystroke_Menu_TWO_TWO(void) // 22
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " P_S__1");
    ips200_showfloat(120, 0, P_S, 4, 2);
    ips200_showstr(8, 1, " D_S__2");
    ips200_showfloat(120, 1, D_S, 4, 2);
    ips200_showstr(8, 2, " G_S__3");
    ips200_showfloat(120, 2, G_S, 4, 2);
    ips200_showstr(8, 3, " Return");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = display;
        display = display * 10 + 1;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 2;
        display = 21;
        ips200_clear(WHITE);
        break;
    }
}
void Keystroke_Menu_TWO_TWO_ONE(void) // 221
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " P_S+__1");
    ips200_showfloat(120, 0, P_S, 4, 2);
    ips200_showstr(8, 1, " P_S-__2");
    ips200_showstr(8, 2, " Step__3");
    ips200_showfloat(120, 2, step, 4, 2);
    ips200_showstr(8, 3, " Return");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        P_S = P_S + step;
        break;
    case KeystrokeTWO:
        P_S = P_S - step;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = 5;
        display = 51;
        step_back = 221;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 22;
        display = 221;
        ips200_clear(WHITE);
        break;
    }
}
void Keystroke_Menu_TWO_TWO_TWO(void) // 222
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " D_S+__1");
    ips200_showfloat(120, 0, D_S, 4, 2);
    ips200_showstr(8, 1, " D_S-__2");
    ips200_showstr(8, 2, " Step__3");
    ips200_showfloat(120, 2, step, 4, 2);
    ips200_showstr(8, 3, " Return");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        D_S = D_S + step;
        break;
    case KeystrokeTWO:
        D_S = D_S - step;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = 5;
        display = 51;
        step_back = 222;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 22;
        display = 221;
        ips200_clear(WHITE);
        break;
    }
}
void Keystroke_Menu_TWO_TWO_THREE(void) // 223
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " G_S+__1");
    ips200_showfloat(120, 0, G_S, 4, 2);
    ips200_showstr(8, 1, " G_S-__2");
    ips200_showstr(8, 2, " step__3");
    ips200_showfloat(120, 2, step, 4, 2);
    ips200_showstr(8, 3, " Return");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        G_S = G_S + step;
        break;
    case KeystrokeTWO:
        G_S = G_S - step;
        break;
    case KeystrokeTHREE:
        Dispay_Codename = 5;
        display = 51;
        step_back = 223;
        ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 22;
        display = 221;
        ips200_clear(WHITE);
        break;
    }
}
//-------------------------------------------------------------------------------------------------------------------
//  @brief      �˵���
//  @param
//  @param
//  @param
//  @param
//  @return     void
//  @note       ��ҳ��Ϊ���Ϊ0
//-------------------------------------------------------------------------------------------------------------------
void Keystroke_Menu_THREE(void) // 3
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " adc_0");
    ips200_showuint16(120, 0, adc_data[0]);
    ips200_showstr(8, 1, " adc_1");
    ips200_showuint16(120, 1, adc_data[1]);
    ips200_showstr(8, 2, " adc_2");
    ips200_showuint16(120, 2, adc_data[2]);
    ips200_showstr(8, 3, " adc_3");
    ips200_showuint16(120, 3, adc_data[3]);
    ips200_showstr(8, 4, " adc_4");
    ips200_showuint16(120, 4, adc_data[4]);
    ips200_showstr(8, 5, " adc_5");
    ips200_showuint16(120, 5, adc_data[5]);
    ips200_showstr(8, 6, " adc_6");
    ips200_showuint16(120, 6, adc_data[6]);
    ips200_showstr(8, 7, " adc_7");
    ips200_showuint16(120, 7, adc_data[7]);
    ips200_showstr(8, 8, " adc_8");
    ips200_showuint16(120, 8, adc_data[8]);
    ips200_showstr(8, 9, " adc_9");
    ips200_showuint16(120, 9, adc_data[9]);

    ips200_showstr(8, 10, " Return");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        // Dispay_Codename = display;
        // display = display*10+1;
        // ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 0;
        display = 1;
        ips200_clear(WHITE);
        break;
    }
}

//-------------------------------------------------------------------------------------------------------------------
//  @brief      �˵���
//  @param
//  @param
//  @param
//  @param
//  @return     void
//  @note       ��ҳ��Ϊ���Ϊ0
//-------------------------------------------------------------------------------------------------------------------
void Keystroke_Menu_FOUR(void) // 3
{
    ips200_Dispaly(BLUE);
    ips200_showstr(0, display % 10 - 1, "*");
    ips200_showstr(8, 0, " P_ZHI");
    ips200_showfloat(120, 0, P_S, 4, 4);
    ips200_showstr(8, 1, " P_WAN");
    ips200_showfloat(120, 1, P_S_MAX, 4, 4);
    ips200_showstr(8, 2, " D_ZHI");
    ips200_showfloat(120, 2, D_S_z, 4, 4);
    ips200_showstr(8, 3, " D_WAN");
    ips200_showfloat(120, 3, D_S, 4, 4);
    ips200_showstr(8, 4, " G_ZHI");
    ips200_showfloat(120, 4, G_S_1, 4, 4);
    ips200_showstr(8, 5, " G_WAN");
    ips200_showfloat(120, 5, G_S, 4, 4);
    ips200_showstr(8, 6, " P_LR");
    ips200_showfloat(120, 6, P_LR, 4, 4);
    ips200_showstr(8, 7, " I_LR");
    ips200_showfloat(120, 7, I_LR, 4, 4);
    ips200_showstr(8, 8, " k");
    ips200_showfloat(120, 8, k, 4, 4);
    ips200_showstr(8, 9, " gyro");
    ips200_showfloat(120, 9, gyro, 4, 4);

    ips200_showstr(8, 10, " Return");
    ips200_showstr(8, 45, " display");
    ips200_showuint16(120, 45, display % 10);
    Keystroke_Scan();
    switch (KeystrokeLabel)
    {
    case KeystrokeONE:
        display += 1;
        break;
    case KeystrokeTWO:
        display -= 1;
        break;
    case KeystrokeTHREE:
        // Dispay_Codename = display;
        // display = display*10+1;
        // ips200_clear(WHITE);
        break;
    case KeystrokeFOUR:
        Dispay_Codename = 0;
        display = 1;
        ips200_clear(WHITE);
        break;
    }
}
